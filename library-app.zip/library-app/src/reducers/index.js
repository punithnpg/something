import { combineReducers } from 'redux'
import books from './booksReducer'

const bookApp = combineReducers({
  books
})

export default bookApp