import React, { Component } from 'react';
import {deleteBook} from  '../actions/index'
import {connect} from 'react-redux'
import { BrowserRouter, Route, Link } from 'react-router-dom'
class bookDetail extends Component {
    
    render(){
      console.log(this.props)
      console.log(this.props.books)
        return (
            <div>
            <nav className="navbar navbar-default">
                <div className="container-fluid">
                    <div className="navbar-header">
                        <a className="navbar-brand" href="#">React Library</a>
                    </div>
                    <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul className="nav navbar-nav">
                            <li>
                                <Link to="/">Library Collection</Link>
                            </li>
                            <li >
                                <Link to="/add" ClassName="active">Add Books</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div ClassName="col-md-6">
     
                
                   <h4 >Title  : {this.props.books[this.props.match.params.id].title } </h4>
                   <h4>Author:  {this.props.books[this.props.match.params.id].author} </h4>
                   <h4>Description:  {this.props.books[this.props.match.params.id].description} </h4>
              
                   <button type="button" class="btn btn-danger" onClick={(e) =>{ this.props.dispatch1(this.props.match.params.id);this.props.history.push("/") }}  > Delete </button>
           </div>
           
           
       </div>
    );
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        books: state.books
    }
}
const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        dispatch1: (id) => {
            dispatch(deleteBook(id))
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(bookDetail);