import React, {Component} from 'react'
import {BrowserRouter, Route, Link} from 'react-router-dom'
import {connect} from 'react-redux';
import { addBook} from '../actions/index'
import {  browserHistory } from 'react-router'

import { bindActionCreators } from 'redux';
class addBooks extends Component {
    constructor(props) {
        super(props);
        this.state = {
            title: '',
            author:'',
            description:''
          
        }

        this.handleTitleChange = this.handleTitleChange.bind(this);
        this.onSubmitHandler=this.onSubmitHandler.bind(this);
        this.handleDescChange =this.handleDescChange.bind(this);
        this.handleAuthorChange = this.handleAuthorChange.bind(this);
        this.onClearHandler = this.onClearHandler.bind(this);
    }
    onClearHandler(event){
        const newState = Object.assign({}, this.state, { title: '',
                author:'',
                description:''})
    }
    handleTitleChange(event) {
        const newState = Object.assign({}, this.state, {title: event.target.value})
        this.setState(newState);
        
    }
    handleDescChange(event) {
        const newState = Object.assign({}, this.state, {description: event.target.value})
        this.setState(newState);
        
    }
   handleAuthorChange(event) {
        const newState = Object.assign({}, this.state, {author: event.target.value})
        this.setState(newState);
        
    }
      onSubmitHandler(event){
        event.preventDefault();
        if(this.state.title!=''&& this.state.author!='' && this.state.description!='')
            {
               
                this.props.addABook(this.state.title, this.state.author, this.state.description)
                const newState = Object.assign({}, this.state, { title: '',
                author:'',
                description:''})
                this.setState(newState);
                this.props.history.push("/")
            }
            else{
                    alert("FILL ALL THE FIELDS")
            }
        
        }

    render() {
        return (
            <div>
                <nav className="navbar navbar-default">
                    <div className="container-fluid">
                        <div className="navbar-header">
                            <a className="navbar-brand" href="#">React Library</a>
                        </div>
                        <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul className="nav navbar-nav">
                                <li>
                                    <Link to="/">Library Collection</Link>
                                </li>
                                <li >
                                    <Link to="/add" ClassName="active">Add Books</Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <div ClassName="col-md-6">
                    
                    
                    <form  onSubmit={this.onSubmitHandler}  >
                        <legend>Add Book</legend>
                    
                        <div class="form-group">
                            <label for="">Title</label>
                            <input type="text" class="form-control" id="" 
                            value={this.state.title} 
                            onChange={this.handleTitleChange}
                            placeholder="Title Here" />
                        </div>
                    
                        <div class="form-group">
                            <label for="">Author</label>
                            <input type="text" class="form-control" id="" 
                            value={this.state.author} 
                            onChange={this.handleAuthorChange}
                            placeholder="Author here" />
                        </div>

                        <div class="form-group">
                            <label for="">Description</label>
                            <textarea class="form-control" id=""
                            value={this.state.description} 
                            onChange={this.handleDescChange}
                            placeholder="Description Here"  />
                        </div>
                    
                        <button type="submit" class="btn btn-primary">Save</button>
                        
                    </form>
                    
                  
                </div>
            </div>
        )
    }
}


const mapStateToProps = (state, ownProps) => {
    return {books: state.books}
}
const mapDispatchToProps = (dispatch) => {
    return {
        addABook: (title,author,description) => dispatch(addBook(title,author,description)),
    }
  }

export default connect(mapStateToProps, mapDispatchToProps)(addBooks)
