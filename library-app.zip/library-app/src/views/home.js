import React, { Component } from 'react';
import { BrowserRouter, Route, Link } from 'react-router-dom'
import { connect } from 'react-redux'


class bookList extends Component {
   
    constructor(props){
      
        super(props);
       
    
    }

    

    render(){
    
        const allBooks = this.props.books.map((book) => {
            return (
                <Link
                to={"/books/"+book.id}
                className="list-group-item"
                key={book.id}>
                    {book.title}
            </Link>
               
            )
        });
        return (
            <div>
                <nav className="navbar navbar-default">
                    <div className="container-fluid">
                        <div className="navbar-header">
                            <a className="navbar-brand" href="#">React Library</a>
                        </div>
                        <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul className="nav navbar-nav">
                            <li><Link to="/" ClassName="active">Library Collection</Link></li>
                                <li ><Link to="/add" >Add Books</Link></li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <div className="col-md-6">
                <h1>Library Collection</h1>
                <div className="list-group">
                {allBooks}
                </div>
                </div>
            </div>
        );
    }
}

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        dispatch1: () => {
            dispatch()
        }
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        books: state.books
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(bookList)