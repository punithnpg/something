import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import { BrowserRouter, Route, Link } from 'react-router-dom'
import bookList from './views/home'
import bookDetail from './views/bookDetail'
import { Provider } from 'react-redux'
import {createStore, applyMiddleware } from  'redux';
import bookApp from './reducers/index'
import addBooks from './views/addBooks'
import thunk from 'redux-thunk';
const initialState = '';
let store = createStore(bookApp,initialState, applyMiddleware(thunk))
ReactDOM.render( 
<Provider store={store}>
<BrowserRouter>
<div>
    <Route exact path="/" component={bookList}/>
    <Route exact path="/add" component={addBooks}/>
    <Route path="/books/:id" component={bookDetail}/>
</div>
</BrowserRouter>
</Provider>, document.getElementById('root'));
registerServiceWorker();
