let nextBookId = 0


export const addBook = (title,discription,author) => ({
    type: 'ADD_BOOK',
    id: nextBookId++,
    title,
    author,
    discription
  })
  

  export const deleteBook = (id) => {
   debugger   
   return (
   
    {
    
    type: 'DELETE_BOOK',
    id
  }
)}